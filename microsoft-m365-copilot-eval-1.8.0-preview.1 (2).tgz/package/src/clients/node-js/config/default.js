/**
 * Build-time injected default values
 * DO NOT EDIT - This file is auto-generated during build.
 *
 * Generated: 2026-05-26T22:37:09.652Z
 *
 * @copyright Microsoft Corporation. All rights reserved.
 * @license MIT
 */

export default {
  workIq: {
    /** Work IQ A2A Endpoint */
    a2aEndpoint: "https://graph.microsoft.com/rp/workiq",

    /** Work IQ A2A Client ID */
    a2aClientId: "ba081686-5d24-4bc6-a0d6-d034ecffed87",

    /** Work IQ A2A OAuth Scopes */
    a2aScopes: "Sites.Read.All Mail.Read People.Read.All OnlineMeetingTranscript.Read.All Chat.Read ChannelMessage.Read.All ExternalItem.Read.All"
  },
  eula: {
    /** EULA version string for acceptance tracking */
    version: "2026-04-01"
  }
};
