"""A2A protocol package.

Import submodules directly (e.g. ``from api_clients.A2A.a2a_client import
A2AClient``) — the package ``__init__`` deliberately re-exports nothing so
leaf modules like :mod:`api_clients.A2A.constants` can be imported without
eagerly loading the full client class.
"""
