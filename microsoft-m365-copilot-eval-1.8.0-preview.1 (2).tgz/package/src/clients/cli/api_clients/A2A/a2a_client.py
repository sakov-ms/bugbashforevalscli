from __future__ import annotations

import functools
import json
import locale
import logging
import re
import urllib.error
import urllib.request
import uuid
from typing import Any, Callable, Dict, Iterable, List, Optional, Tuple

from api_clients.A2A.constants import (
    ARTIFACT_DESCRIPTORS,
    AcceptedOutputMode,
)
from api_clients.base_agent_client import BaseAgentClient
from cli_logging.console_diagnostics import emit_structured_log
from cli_logging.logging_utils import Operation

# Feature flag required by the experimental A2A surface.
_A2A_FEATURE_FLAG = "feature.EnableA2AServer"

_REQUEST_TIMEOUT_SECS = 120

# Lookup derived from ARTIFACT_DESCRIPTORS for use in the response parser:
# server returns artifacts by name, we expose them under a stable key.
_ARTIFACT_NAME_TO_RESULT_KEY: Dict[str, str] = dict(ARTIFACT_DESCRIPTORS.values())

# OAI citation marker patterns — compiled once at module level.
# Marker format: \ue200cite(\ue202turn{X}search{Y})+\ue201
_CITATION_REF_PAT = re.compile(r"\ue202turn\d+search(\d+)")
_CITATION_BLOCK_PAT = re.compile(r"\ue200cite(?:\ue202turn\d+search\d+)+\ue201")


class A2AClient(BaseAgentClient):
    """A2A (Agent-to-Agent) JSON-RPC 2.0 client for Work IQ agents."""

    def __init__(
        self,
        *,
        a2a_endpoint: str,
        access_token: str,
        logger: Optional[logging.Logger] = None,
        diagnostic_records: Optional[List[Dict[str, Any]]] = None,
        token_refresh_fn: Optional[Callable[[], str]] = None,
    ) -> None:
        """
        Args:
            a2a_endpoint: Base URL of the A2A endpoint.
            access_token: Bearer token for A2A authentication.
            logger: Logger to use. Defaults to a module-level logger if not provided.
            diagnostic_records: List to accumulate structured log entries.
            token_refresh_fn: Optional callable that returns a fresh access token string.
                When provided, a single HTTP 401 response will trigger a token refresh
                and one automatic retry, making the refresh invisible to the caller.
        """
        self._endpoint = a2a_endpoint.rstrip("/")
        self._access_token = access_token
        self._logger = logger or logging.getLogger(__name__)
        self._diagnostic_records = diagnostic_records
        self._token_refresh_fn = token_refresh_fn
        self._resolved_agent_url: Optional[str] = None
        self._missing_artifact_warned: set[Tuple[Optional[str], str]] = set()

    # ------------------------------------------------------------------ #
    #  BaseAgentClient implementation                                     #
    # ------------------------------------------------------------------ #

    def resolve_agent(self, agent_id: str) -> None:
        """Pre-resolve agent URL from agent card and cache for the session."""
        self._resolved_agent_url = self._resolve_agent_url(agent_id)

    def fetch_available_agents(self) -> List[Dict[str, Any]]:
        """Fetch agents from the A2A discovery endpoint.

        Calls GET {endpoint}/.agents. Each A2A agent card is normalized to
        include 'gptId', 'name', and 'provider' so it is compatible with
        the shared select_agent_interactively selector.

        Returns an empty list if the endpoint is unreachable or returns an
        error.
        """
        try:
            agents_url = f"{self._endpoint}/.agents"
            headers = self._build_request_headers()
            emit_structured_log(
                "debug",
                f"[A2A] Fetching available agents from: {agents_url}",
                Operation.FETCH_AGENTS,
                logger=self._logger,
                diagnostic_records=self._diagnostic_records,
            )
            req = urllib.request.Request(agents_url, headers=headers, method="GET")
            with urllib.request.urlopen(req, timeout=_REQUEST_TIMEOUT_SECS) as resp:
                agents = json.loads(resp.read().decode("utf-8"))
            emit_structured_log(
                "debug",
                f"[A2A] Available agents response: {json.dumps(agents)}",
                Operation.FETCH_AGENTS,
                logger=self._logger,
                diagnostic_records=self._diagnostic_records
            )
            return [self._normalize_agent_card(a) for a in agents]
        except urllib.error.HTTPError as e:
            emit_structured_log(
                "warning",
                f"[A2A] Unable to fetch agents list (HTTP {e.code}).",
                Operation.FETCH_AGENTS,
                logger=self._logger,
                diagnostic_records=self._diagnostic_records,
            )
            return []
        except Exception as e:
            emit_structured_log(
                "warning",
                f"[A2A] Error fetching agents: {e}",
                Operation.FETCH_AGENTS,
                logger=self._logger,
                diagnostic_records=self._diagnostic_records,
            )
            return []

    @staticmethod
    def _normalize_agent_card(agent: Dict[str, Any]) -> Dict[str, Any]:
        """Normalize an A2A agent card to the shape expected by the selector.
        """
        return {
            "gptId": agent.get("agentId"),
            "name": agent.get("name"),
            "provider": agent.get("provider")
        }

    def send_prompt(
        self,
        prompt: str,
        agent_id: str | None = None,
        conversation_context: Optional[Dict[str, Any]] = None,
        *,
        accepted_output_modes: Optional[Iterable[AcceptedOutputMode]] = None,
    ) -> Tuple[Dict[str, Any], Optional[Dict[str, Any]]]:
        """Send a single prompt to the A2A endpoint and return the response with context.

        Args:
            prompt: The prompt string to send.
            agent_id: Target agent ID. Required for A2A — no fallback discovery.
            conversation_context: Context from a previous turn (contains context_id),
                or None for the first turn / single-turn usage.
            accepted_output_modes: A2A media types for
                ``configuration.acceptedOutputModes`` (use constants from
                :mod:`api_clients.A2A.constants`). ``None`` or empty omits
                the configuration block; callers compose this list per-prompt
                so non-retrieval prompts stay on the lighter payload path.

        Returns:
            Tuple of (enhanced_response_dict, conversation_context).
        """
        agent_id = (agent_id or "").strip()
        if not agent_id:
            raise ValueError("agent_id is required for A2A requests.")

        headers = self._build_request_headers(include_content_type=True)
        agent_url = self._resolved_agent_url or self._resolve_agent_url(agent_id)

        context_id = conversation_context.get("context_id") if conversation_context else None

        emit_structured_log(
            "debug",
            "[A2A] Sending prompt to agent.",
            Operation.SEND_PROMPT,
            logger=self._logger,
            diagnostic_records=self._diagnostic_records,
        )

        # Materialize once: needed for both the payload and the
        # post-response missing-artifact check.
        requested_modes = list(accepted_output_modes) if accepted_output_modes else []

        payload = self._build_chat_payload(
            prompt,
            context_id,
            accepted_output_modes=requested_modes,
        )

        emit_structured_log(
            "debug",
            f"[A2A] Sending to {agent_url}: {payload.decode('utf-8')}",
            Operation.SEND_PROMPT,
            logger=self._logger,
            diagnostic_records=self._diagnostic_records,
        )

        result_dict, raw_result = self._send_and_parse_message(agent_url, payload, headers)

        # Surface missing opted-in artifacts. First occurrence per
        # (agent_id, mode) is a warning; subsequent occurrences drop to
        # debug to avoid a flood when an agent doesn't yet support the
        # requested mode across a large prompt set.
        for mode in requested_modes:
            descriptor = ARTIFACT_DESCRIPTORS.get(mode)
            if descriptor is None:
                continue
            _, result_key = descriptor
            if result_key not in result_dict:
                seen_key = (agent_id, mode)
                level = "debug" if seen_key in self._missing_artifact_warned else "warning"
                self._missing_artifact_warned.add(seen_key)
                emit_structured_log(
                    level,
                    f"[A2A] Requested output mode '{mode}' but no matching artifact was returned.",
                    Operation.SEND_PROMPT,
                    logger=self._logger,
                    diagnostic_records=self._diagnostic_records,
                )

        # Build updated context for subsequent turns
        new_context_id = context_id
        if raw_result:
            new_context_id = raw_result.get("contextId") or context_id
        updated_context = {"context_id": new_context_id} if new_context_id else None

        return result_dict, updated_context

    # ------------------------------------------------------------------ #
    #  Private helpers                                                    #
    # ------------------------------------------------------------------ #

    def _build_request_headers(self, *, include_content_type: bool = False) -> Dict[str, str]:
        headers: Dict[str, str] = {
            "Authorization": f"Bearer {self._access_token}",
            "X-variants": _A2A_FEATURE_FLAG,
        }
        if include_content_type:
            headers["Content-Type"] = "application/json"
        return headers

    def _build_chat_payload(
        self,
        prompt: str,
        context_id: str | None = None,
        *,
        accepted_output_modes: Optional[Iterable[AcceptedOutputMode]] = None,
    ) -> bytes:
        message: Dict[str, Any] = {
            "kind": "message",
            "role": "user",
            "parts": [{"kind": "text", "text": prompt}],
            "messageId": str(uuid.uuid4()),
            "metadata": {
                "location": self._get_a2a_location(),
            },
        }
        if context_id:
            message["contextId"] = context_id

        params: Dict[str, Any] = {"message": message}
        # Per-prompt opt-in: omit the configuration block on default prompts
        # to keep response payloads small.
        #
        # ``dict.fromkeys`` dedupes while
        # preserving order, matching A2A's preference-ordered
        # ``acceptedOutputModes`` semantics.
        modes = list(dict.fromkeys(accepted_output_modes or ()))
        if modes:
            params["configuration"] = {
                "acceptedOutputModes": modes,
                "blocking": True,
            }

        return json.dumps({
            "jsonrpc": "2.0",
            "method": "message/send",
            "params": params,
            "id": str(uuid.uuid4()),
        }).encode("utf-8")

    @staticmethod
    @functools.lru_cache(maxsize=1)
    def _get_a2a_location() -> Dict[str, Any]:
        locale_str = locale.getlocale()[0] or ""
        country = locale_str.split("_")[-1] if "_" in locale_str else ""
        return {
            "countryOrRegion": country,
            "countryOrRegionConfidence": 1.0,
            "timeZone": BaseAgentClient._get_iana_timezone_name(),
        }

    def _resolve_agent_url(self, agent_id: str) -> str:
        """Resolve the agent URL from the agent card, falling back to base URL.

        """
        headers = self._build_request_headers(include_content_type=True)
        base_agent_url = f"{self._endpoint}/{agent_id}"
        card_url = f"{base_agent_url}/.well-known/agent-card.json"
        agent_url = base_agent_url
        emit_structured_log(
            "debug",
            f"[A2A] Fetching agent card from: {card_url}",
            Operation.FETCH_AGENTS,
            logger=self._logger,
            diagnostic_records=self._diagnostic_records,
        )
        try:
            card_req = urllib.request.Request(card_url, headers=headers)
            with urllib.request.urlopen(card_req, timeout=_REQUEST_TIMEOUT_SECS) as resp:
                raw_card = resp.read().decode("utf-8")
            if raw_card.strip():
                card = json.loads(raw_card)
                agent_url = card.get("url") or base_agent_url
        except (urllib.error.HTTPError, urllib.error.URLError, json.JSONDecodeError, UnicodeDecodeError) as e:
            emit_structured_log(
                "debug",
                f"[A2A] Agent card fetch failed ({e}); using base URL: {base_agent_url}",
                Operation.FETCH_AGENTS,
                logger=self._logger,
                diagnostic_records=self._diagnostic_records,
            )
        emit_structured_log(
            "debug",
            f"[A2A] Resolved agent URL: {agent_url}",
            Operation.SEND_PROMPT,
            logger=self._logger,
            diagnostic_records=self._diagnostic_records,
        )
        return agent_url

    def _send_and_parse_message(
        self,
        agent_url: str,
        payload: bytes,
        headers: Dict[str, str],
    ) -> tuple[Dict[str, Any], Dict[str, Any]]:
        """Send a JSON-RPC message to the agent and parse the response.

        When a ``token_refresh_fn`` was supplied at construction time and the
        server responds with HTTP 401 (Unauthorized), the token is refreshed
        automatically and the request is retried exactly once.  This keeps
        long-running eval sessions alive beyond the initial token lifetime
        without requiring any user interaction.

        Returns:
            A tuple of (result_dict, raw_result) where result_dict is the
            normalized response dict (raw_response_text, display_response_text,
            a2a_attributions) and raw_result is the parsed JSON result object.

        Raises:
            RuntimeError: On HTTP errors, connection errors, JSON parse errors,
                or A2A protocol errors.
        """
        req = urllib.request.Request(agent_url, data=payload, headers=headers, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=_REQUEST_TIMEOUT_SECS) as resp:
                raw = resp.read().decode("utf-8", errors="replace")
        except urllib.error.HTTPError as e:
            if e.code == 401 and self._token_refresh_fn is not None:
                emit_structured_log(
                    "info",
                    "[A2A] Access token expired (HTTP 401); refreshing token and retrying.",
                    Operation.AUTHENTICATE,
                    logger=self._logger,
                    diagnostic_records=self._diagnostic_records,
                )
                new_token = self._token_refresh_fn()
                if not new_token:
                    raise RuntimeError(
                        "A2A request failed (HTTP 401 Unauthorized) and token refresh returned no token."
                    ) from e
                self._access_token = new_token
                headers["Authorization"] = f"Bearer {self._access_token}"
                retry_req = urllib.request.Request(
                    agent_url, data=payload, headers=headers, method="POST"
                )
                try:
                    with urllib.request.urlopen(retry_req, timeout=_REQUEST_TIMEOUT_SECS) as resp:
                        raw = resp.read().decode("utf-8", errors="replace")
                except urllib.error.HTTPError as retry_e:
                    body = ""
                    try:
                        body = retry_e.read().decode("utf-8", errors="replace")
                    except Exception:
                        pass
                    raise RuntimeError(
                        f"A2A request failed (HTTP {retry_e.code} {retry_e.reason}) after token refresh."
                        + (f" Body: {body}" if body else "")
                    ) from retry_e
                except urllib.error.URLError as retry_e:
                    raise RuntimeError(
                        f"A2A connection error after token refresh: {getattr(retry_e, 'reason', str(retry_e))}"
                    ) from retry_e
            else:
                body = ""
                try:
                    body = e.read().decode("utf-8", errors="replace")
                except Exception:
                    pass
                raise RuntimeError(
                    f"A2A request failed (HTTP {e.code} {e.reason})."
                    + (f" Body: {body}" if body else "")
                ) from e
        except urllib.error.URLError as e:
            raise RuntimeError(
                f"A2A connection error: {getattr(e, 'reason', str(e))}"
            ) from e

        emit_structured_log(
            "debug",
            f"[A2A] Raw response: {raw}",
            Operation.SEND_PROMPT,
            logger=self._logger,
            diagnostic_records=self._diagnostic_records,
        )

        try:
            data = json.loads(raw)
        except json.JSONDecodeError as e:
            raise RuntimeError(f"A2A response is not valid JSON: {e}") from e

        if "error" in data:
            err = data["error"]
            raise RuntimeError(
                f"A2A JSON-RPC error {err.get('code', 'unknown')}: {err.get('message', 'no message')}"
            )

        if "result" not in data:
            raise RuntimeError(
                f"A2A response missing 'result' key. Keys present: {list(data.keys())}"
            )

        result = data["result"]
        kind = result.get("kind")
        text = ""
        attributions: List[Dict[str, Any]] = []

        # Map of result-dict key → extracted data dict for any A2A artifact
        # listed in :data:`constants.ARTIFACT_NAME_TO_RESULT_KEY`. Extensible:
        # add a new entry to that map (and a new media-type constant if the
        # artifact requires opt-in) and this loop picks it up without further
        # changes.
        extracted_artifacts: Dict[str, Dict[str, Any]] = {}

        if kind == "message":
            text = "\n".join(
                p.get("text", "")
                for p in result.get("parts", [])
                if p.get("kind") == "text"
            )
            attributions = result.get("metadata", {}).get("attributions", [])
        elif kind == "task":
            state = result.get("status", {}).get("state")
            if state == "completed":
                msg = result.get("status", {}).get("message") or {}
                all_parts = list(msg.get("parts", []))
                for artifact in result.get("artifacts", []):
                    artifact_name = artifact.get("name")
                    if artifact_name in _ARTIFACT_NAME_TO_RESULT_KEY:
                        data = self._extract_artifact_part_data(
                            artifact, artifact_name
                        )
                        if data is not None:
                            result_key = _ARTIFACT_NAME_TO_RESULT_KEY[artifact_name]
                            extracted_artifacts[result_key] = data
                    all_parts.extend(artifact.get("parts", []))
                text = "\n".join(
                    p.get("text", "")
                    for p in all_parts
                    if p.get("kind") == "text"
                )
                attributions = msg.get("metadata", {}).get("attributions", [])
            elif state in ("failed", "canceled", "rejected"):
                status_msg = result.get("status", {}).get("message") or {}
                detail = "\n".join(
                    p.get("text", "")
                    for p in status_msg.get("parts", [])
                    if p.get("kind") == "text"
                ).strip()
                suffix = f" Detail: {detail}" if detail else ""
                raise RuntimeError(
                    f"A2A task {state}. Task id: {result.get('id')}{suffix}"
                )
            elif state in ("input_required", "auth_required"):
                requirement = {
                    "input_required": "user input",
                    "auth_required": "authentication",
                }.get(state, state.replace("_", " "))
                raise RuntimeError(
                    f"A2A task requires {requirement} and cannot proceed automatically."
                    f" Task id: {result.get('id')}"
                )
            elif state in ("submitted", "working"):
                raise RuntimeError(
                    f"A2A task is still {state}; synchronous send returned before completion."
                    f" Task id: {result.get('id')}"
                )
            else:
                raise RuntimeError(
                    f"A2A task in unexpected state: {state!r}. Task id: {result.get('id')}"
                )
        else:
            raise RuntimeError(f"Unexpected A2A result kind: {kind!r}")

        display_text = self._replace_citation_markers(text, attributions)

        result_dict: Dict[str, Any] = {
            "raw_response_text": text,
            "display_response_text": display_text,
            "a2a_attributions": attributions,
            "metadata": {
                "conversation_id": result.get("contextId"),
            },
        }
        for result_key, data in extracted_artifacts.items():
            result_dict[result_key] = data
        return result_dict, result

    @staticmethod
    def _extract_artifact_part_data(
        artifact: Dict[str, Any],
        artifact_name: str,
    ) -> Optional[Dict[str, Any]]:
        """Extract the first data payload from an artifact matching the given name.

        Returns the ``data`` field of the first ``kind="data"`` part when
        ``artifact["name"] == artifact_name`` and the data is a dict, or None
        otherwise.
        """
        if artifact.get("name") != artifact_name:
            return None
        for part in artifact.get("parts", []):
            if part.get("kind") == "data":
                data = part.get("data")
                if isinstance(data, dict):
                    return data
        return None

    @staticmethod
    def _replace_citation_markers(
        text: str,
        attributions: List[Dict[str, Any]],
    ) -> str:
        """Replace OAI Unicode citation markers with markdown links.

        Marker format: \\ue200cite(\\ue202turn{X}search{Y})+\\ue201
        Compound markers (multiple turn/search refs between a single pair of
        bookend characters) are also handled.

        The search{Y} number is NOT a direct array index — it's a grounding result
        number. Mapping: unique search numbers in first-appearance order →
        citation_attrs[0, 1, ...].

        Args:
            text: Response text that may contain OAI citation markers.
            attributions: Attribution objects from A2A response metadata.

        Returns:
            Text with citation markers replaced by markdown links, or the
            original text unchanged if there are no citation attributions.
        """
        citation_attrs = [a for a in attributions if a.get("attributionType") == "citation"]
        if not text:
            return text
        if not citation_attrs:
            return text

        # Build ordered map: search-number-string → 0-based index into citation_attrs
        seen: Dict[str, int] = {}
        for m in _CITATION_REF_PAT.finditer(text):
            k = m.group(1)
            if k not in seen:
                seen[k] = len(seen)

        def replace_citation(m: re.Match) -> str:
            links = []
            for idx_str in _CITATION_REF_PAT.findall(m.group(0)):
                pos = seen.get(idx_str)
                if pos is not None and pos < len(citation_attrs):
                    attr = citation_attrs[pos]
                    url = attr.get("seeMoreWebUrl") or ""
                    label = attr.get("providerDisplayName") or url or idx_str
                    if url:
                        links.append(f"[{label}]({url})")
            return " ".join(links)

        return _CITATION_BLOCK_PAT.sub(replace_citation, text)
