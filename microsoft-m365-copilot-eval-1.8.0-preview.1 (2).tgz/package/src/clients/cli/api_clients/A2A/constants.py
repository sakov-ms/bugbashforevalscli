"""A2A protocol constants shared across modules."""

from enum import StrEnum
from typing import Dict, Tuple


class AcceptedOutputMode(StrEnum):
    """A2A media types for ``configuration.acceptedOutputModes``.

    Members are ``str`` subclasses, so they serialize directly to the wire
    string without any conversion. To register a new opt-in diagnostic
    artifact, add a member here AND a matching entry in
    :data:`ARTIFACT_DESCRIPTORS`.
    """

    RETRIEVAL = "application/vnd.ms-workiq-internal.retrieval"


# Single source of truth for opt-in A2A diagnostic artifacts. Each entry
# describes one artifact:
#   key   — the accepted-output-mode media type the client requests
#   value — (server-side artifact name as it appears in
#           ``result.artifacts[].name``, key used to expose the extracted
#           data on the enhanced response dict consumed by evaluators)
# Adding a new artifact = add one enum member above and one entry here.
ARTIFACT_DESCRIPTORS: Dict[AcceptedOutputMode, Tuple[str, str]] = {
    AcceptedOutputMode.RETRIEVAL: ("Retrieval Info", "retrieval_info"),
}
