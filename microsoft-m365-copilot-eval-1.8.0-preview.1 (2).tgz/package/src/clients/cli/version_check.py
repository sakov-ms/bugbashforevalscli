"""
Minimum version check for the M365 Copilot Agent Evaluation CLI.

Strategy:
  The published package.json contains a custom "minCliVersion" field.
  At runtime the CLI fetches the latest published package metadata via
  an aka.ms redirect that points to the npm registry API:

      https://aka.ms/m365-evals-min-version
        -> https://registry.npmjs.org/@microsoft/m365-copilot-eval/latest

  The response is the full published package.json as JSON. We simply
  read the "minCliVersion" field and compare it against the local
  version.

  Using aka.ms as an intermediary lets us change the target endpoint
  without shipping a new CLI version.
"""

import json
import os
import urllib.request
import urllib.error
from typing import Optional

from packaging.version import Version, InvalidVersion

# The public npm package name
NPM_PACKAGE_NAME = "@microsoft/m365-copilot-eval"

# npm registry API URL via aka.ms redirect
MIN_VERSION_URL = "https://aka.ms/m365-evals-min-version"

# Timeout for fetching from the registry (seconds) — kept short to fail fast
FETCH_TIMEOUT = 3


def get_cli_version(quiet: bool = False) -> Optional[Version]:
    """
    Read the current CLI version from package.json at the repo root.

    release-please keeps package.json's "version" field up to date,
    so there is no need for a hardcoded version constant.

    Args:
        quiet: If True, suppress warning output on failure.

    Returns:
        A parsed Version object (e.g. Version('1.1.1-preview.1')),
        or None if package.json cannot be read or the version is
        unparseable.
    """
    try:
        # Walk up from this file (src/clients/cli/) to the repo root
        here = os.path.dirname(os.path.abspath(__file__))
        package_json_path = os.path.join(here, "..", "..", "..", "package.json")
        package_json_path = os.path.normpath(package_json_path)
        with open(package_json_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return Version(data.get("version"))
    except Exception as e:
        if not quiet:
            print(
                f"\033[33mWarning: Could not determine current CLI version: {e}\033[0m"
            )
        return None


def fetch_min_version(quiet: bool = False) -> Optional[Version]:
    """
    Fetch the minimum required CLI version from the npm registry.

    How it works:
      1. GET https://registry.npmjs.org/@microsoft/m365-copilot-eval/latest
      2. The response is the published package.json as plain JSON.
      3. Read the "minCliVersion" field.

    Args:
        quiet: If True, suppress warning output on failure.

    Returns:
        A parsed Version object (e.g. Version('1.3.0')),
        or None on any failure.
    """
    try:
        req = urllib.request.Request(
            MIN_VERSION_URL,
            headers={
                "Accept": "application/json",
            },
        )
        with urllib.request.urlopen(req, timeout=FETCH_TIMEOUT) as resp:
            data = json.loads(resp.read().decode("utf-8"))

        return Version(data.get("minCliVersion"))

    except Exception as e:
        if not quiet:
            print(
                f"\033[33mWarning: Could not fetch minimum version from registry: {e}\033[0m"
            )
        return None


def check_min_version(current_version: Optional[Version], quiet: bool = False) -> bool:
    """
    Check whether the current CLI version meets the minimum required version
    published in the npm registry.

    Args:
        current_version: The parsed Version this CLI is running
                         (from get_cli_version()), or None if version
                         cannot be determined.
        quiet:           If True, suppress informational output.

    Returns:
        True if the version is acceptable (>= minVersion or check failed
        gracefully), False if the current version is below the minimum.
    """
    # Fail open if current version unknown (package.json missing/unreadable)
    if current_version is None:
        return True

    min_version = fetch_min_version(quiet=quiet)

    if min_version is None:
        return True

    if current_version < min_version:
        print(
            f"\033[91m"
            f"This version, {current_version}, of the M365 Evals CLI is no longer functional, "
            f"you must update your tool to continue using it.\n"
            f"Update by running: npm install -g {NPM_PACKAGE_NAME}@latest"
            f"\033[0m"
        )
        return False

    return True
