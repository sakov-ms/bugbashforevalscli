"""M365 Copilot Agent Evaluation CLI — thin orchestrator.

Delegates to focused modules:
  cli_args          – argument parsing & version-check bypass
  env_validator     – environment validation & URL security
  prompt_loader     – dataset loading & agent selection
  evaluation_runner – pipeline, evaluator dispatch, retry
  result_writer     – console / JSON / CSV / HTML output
"""

import os
import sys
import traceback

from azure.ai.evaluation import AzureOpenAIModelConfiguration
from dotenv import load_dotenv

from api_clients.A2A.a2a_client import A2AClient
from auth.auth_handler import AuthHandler, make_token_refresh_fn
from evaluator_resolver import resolve_default_evaluators
from version_check import check_min_version, get_cli_version

from cli_logging.cli_logger import (
    CLI_LOGGER,
    DIAGNOSTIC_RECORDS,
    configure_cli_logging,
    emit_structured_log,
)
from cli_logging.logging_utils import Operation, resolve_log_level

from cli_args import parse_arguments, should_bypass_min_version_check
from env_validator import (
    ALLOWED_ENDPOINTS,
    validate_endpoint_url,
    validate_environment,
)
from common import (
    ENV_AZURE_AI_OPENAI_ENDPOINT,
    ENV_AZURE_AI_API_KEY,
    ENV_AZURE_AI_API_VERSION,
    ENV_AZURE_AI_MODEL_NAME,
    ENV_TENANT_ID,
    ENV_WORK_IQ_A2A_ENDPOINT,
    ENV_WORK_IQ_A2A_CLIENT_ID,
    ENV_WORK_IQ_A2A_SCOPES,
    RunConfig,
)
from prompt_loader import get_prompt_datasets
from agent_selector import select_agent_interactively
from evaluation_runner import PipelineConfig, run_pipeline
from result_writer import output_results

from dataclasses import replace


def main():
    """Main function to orchestrate the evaluation process."""
    load_dotenv()
    args = parse_arguments()

    effective_log_level, error_message = resolve_log_level(args.log_level)
    if error_message:
        print(error_message)
        print(
            "Next step: rerun with --log-level {debug|info|warning|error}. "
            "For support, share the console diagnostics output from this run."
        )
        sys.exit(2)

    config = replace(
        RunConfig.from_namespace(args),
        effective_log_level=effective_log_level,
    )
    configure_cli_logging(config.effective_log_level)
    emit_structured_log("info", f"Log level set to '{config.effective_log_level}'.", operation=Operation.SETUP)

    # Check minimum version before proceeding
    quiet_for_version = config.effective_log_level in ("warning", "error")
    cli_version = get_cli_version(quiet=quiet_for_version)
    if not should_bypass_min_version_check(config) and not check_min_version(cli_version, quiet=quiet_for_version):
        sys.exit(1)

    # Validate environment variables required for evaluation
    validate_environment()

    a2a_endpoint = os.environ[ENV_WORK_IQ_A2A_ENDPOINT]
    validate_endpoint_url(a2a_endpoint, ALLOWED_ENDPOINTS)

    a2a_scopes_str = os.environ.get(ENV_WORK_IQ_A2A_SCOPES, "")
    a2a_auth_handler = AuthHandler(
        client_id=os.environ[ENV_WORK_IQ_A2A_CLIENT_ID],
        tenant_id=os.environ[ENV_TENANT_ID],
        scopes_str=a2a_scopes_str,
    )
    if config.signout:
        try:
            a2a_auth_handler.clear_cache()
        except Exception as e:
            emit_structured_log(
                "error",
                f"Error during signout: {e}",
                operation=Operation.AUTHENTICATE,
            )
            sys.exit(1)
        sys.exit(0)

    try:
        a2a_auth_result = a2a_auth_handler.acquire_token_interactive() or {}
        a2a_access_token = a2a_auth_result.get("access_token") or ""
        if not a2a_access_token:
            raise RuntimeError("Failed to acquire A2A access token")
    except Exception as e:
        emit_structured_log(
            "error",
            f"Error during A2A authentication: {e}",
            operation=Operation.AUTHENTICATE,
        )
        if config.effective_log_level == "debug":
            traceback.print_exc()
        sys.exit(1)
    try:
        agent_client = A2AClient(
            a2a_endpoint=a2a_endpoint,
            access_token=a2a_access_token,
            token_refresh_fn=make_token_refresh_fn(a2a_auth_handler),
            logger=CLI_LOGGER,
            diagnostic_records=DIAGNOSTIC_RECORDS,
        )
    except Exception as e:
        emit_structured_log(
            "error",
            f"Failed to initialize A2A client: {e}",
            operation=Operation.SETUP,
        )
        sys.exit(1)

    # 1. Load evaluation datasets
    eval_items, file_default_evaluators = get_prompt_datasets(config)
    default_evaluators = resolve_default_evaluators(file_default_evaluators)

    if config.effective_log_level in ("info", "debug"):
        multi_turn_count = sum(1 for item in eval_items if "turns" in item)
        single_turn_count = len(eval_items) - multi_turn_count
        emit_structured_log(
            "info",
            f"Running evaluation on {len(eval_items)} item(s) "
            f"({single_turn_count} single-turn, {multi_turn_count} multi-turn).",
            operation=Operation.SETUP,
        )

    agent_name = None
    try:
        # 2. Agent selection - when no agent ID is provided, discover agents
        # via the active client (A2A) and prompt interactively.
        if not config.m365_agent_id:
            if config.effective_log_level in ("info", "debug"):
                emit_structured_log("info", "No agent ID provided. Fetching available agents.", operation=Operation.FETCH_AGENTS)

            available_agents = agent_client.fetch_available_agents()
            if not available_agents:
                emit_structured_log(
                    "error",
                    "No agents are available for interactive selection."
                    " Re-run with --m365-agent-id or set M365_AGENT_ID.",
                    operation=Operation.FETCH_AGENTS,
                )
                sys.exit(1)

            selected_agent_id, agent_name = select_agent_interactively(available_agents)
            if selected_agent_id:
                config = replace(config, m365_agent_id=selected_agent_id)
                if config.effective_log_level in ("info", "debug"):
                    emit_structured_log("info", f"Selected agent: {config.m365_agent_id}", operation=Operation.FETCH_AGENTS)
            else:
                emit_structured_log(
                    "error",
                    "No agent selected. Re-run with --m365-agent-id or set M365_AGENT_ID.",
                    operation=Operation.FETCH_AGENTS,
                )
                sys.exit(1)
    except Exception as e:
        emit_structured_log("error", f"Error during agent discovery: {e}", operation=Operation.FETCH_AGENTS)
        if config.effective_log_level == "debug":
            traceback.print_exc()
        sys.exit(1)

    # Pre-resolve agent endpoint (A2A agent card lookup)
    if config.m365_agent_id:
        agent_client.resolve_agent(config.m365_agent_id)

    # 3. Build pipeline config and run evaluation pipeline
    model_config = AzureOpenAIModelConfiguration(
        azure_endpoint=os.environ.get(ENV_AZURE_AI_OPENAI_ENDPOINT),
        api_key=os.environ.get(ENV_AZURE_AI_API_KEY),
        api_version=os.environ.get(ENV_AZURE_AI_API_VERSION),
        azure_deployment=os.environ.get(ENV_AZURE_AI_MODEL_NAME),
    )
    has_azure_openai = bool(
        os.environ.get(ENV_AZURE_AI_OPENAI_ENDPOINT)
        and os.environ.get(ENV_AZURE_AI_API_KEY)
    )

    pipeline = PipelineConfig(
        agent_client=agent_client,
        model_config=model_config,
        has_azure_openai=has_azure_openai,
        default_evaluators=default_evaluators,
    )

    results = run_pipeline(pipeline, eval_items, config)

    # 4. Output results
    output_results(
        results, config, default_evaluators=default_evaluators,
        agent_name=agent_name, cli_version=str(cli_version) if cli_version else None)
    
    if config.effective_log_level in ("info", "debug"):
        emit_structured_log(
            "info",
            f"Evaluation completed successfully. Processed {len(eval_items)} item(s).",
            operation=Operation.EVALUATE,
        )

# Call the main function when script is run directly
if __name__ == "__main__":  # pragma: no cover
    main()
