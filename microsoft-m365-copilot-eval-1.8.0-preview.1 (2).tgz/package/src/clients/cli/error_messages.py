"""Canonical error-message templates for persisted evaluation output.

Every error string written into a JSON/CSV/HTML output file MUST be produced
by a builder in this module. The builders accept only string arguments — never
exception objects — which keeps ``repr(exc)``, ``traceback.format_exc()``, and
SDK class names out of persisted output by construction.

Two flavours:

* **Turn/item-level `ErrorObject` builders** return a structured ``{code, message}``
  dict for the top-level ``error`` field on a turn or single-turn item. Used
  when ``status == "error"`` (cause) or ``status == "partial"`` with at least
  one errored evaluator (summary).

* **Per-evaluator string builders** return a flat string formatted as
  ``"<category prefix>: <detail>"`` for the ``error`` field inside an
  ``ErroredScore`` entry. Evaluator identity is encoded by the ``scores`` map's
  parent property key, so no ``code`` is needed at this level.
"""

from __future__ import annotations

from typing import TypedDict


class ErrorObject(TypedDict):
    """Turn/item-level top-level error shape — `{code, message}` per ErrorObject $def."""
    code: str
    message: str


# ── Error code constants ──────────────────────────────────────────────
# These are the canonical machine-readable codes emitted in the top-level
# `error.code` field. They appear in persisted output and consumer-facing
# documentation; treat the string values as part of the public contract
# (do not rename without a schema-version bump).

ERROR_CODE_AGENT_REQUEST_FAILED = "agentRequestFailed"
ERROR_CODE_TURN_SKIPPED = "turnSkipped"
ERROR_CODE_EVALUATORS_FAILED = "evaluatorsFailed"


# ── Turn/item-level ErrorObject builders ──────────────────────────────


def agent_request_failed(exc_message: str) -> ErrorObject:
    """`status == "error"` cause when the agent client raised — no response obtained."""
    return {
        "code": ERROR_CODE_AGENT_REQUEST_FAILED,
        "message": f"Agent request failed: {exc_message}",
    }


def turn_skipped() -> ErrorObject:
    """`status == "error"` cause for downstream turns after a preceding turn failed.

    Synthesized cause — no exception text appended (FR-013).
    """
    return {
        "code": ERROR_CODE_TURN_SKIPPED,
        "message": "Turn not attempted: preceding turn failed",
    }


def evaluators_failed_summary(error_count: int, total: int) -> ErrorObject:
    """`status == "partial"` summary when at least one evaluator returned `result: "error"`.

    Unified template regardless of error_count vs total — per-evaluator detail
    (crash vs missing-prereq, with optional exception text) lives in `scores`.
    """
    return {
        "code": ERROR_CODE_EVALUATORS_FAILED,
        "message": f"Agent response obtained. {error_count} of {total} evaluators failed to run.",
    }


# ── Per-evaluator string builders (inside `scores`) ──────────────────


def evaluator_failed(exc_message: str) -> str:
    """Per-evaluator `error` string when the evaluator raised during run."""
    return f"Evaluator failed: {exc_message}"


# Per-evaluator prerequisite-miss builders are not present today because no
# reachable prereq-fail exists: `validate_environment()` exits the process if
# Azure OpenAI config is missing, and no registered evaluator has a
# data-dependent prereq. When that changes, add builders following the
# convention `"Evaluator missing prerequisites: <description>"` and wire a
# prereq check in evaluation_runner. See specs/236-unified-error-output for
# the deferred sub-cases.
