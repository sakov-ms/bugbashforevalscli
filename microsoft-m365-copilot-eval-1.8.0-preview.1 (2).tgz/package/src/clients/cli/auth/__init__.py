# Authentication module for token acquisition
