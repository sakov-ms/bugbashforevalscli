"""RetrievalResultEvaluator — validates retrieved content via extract assertions.

V1 ships ``retrievalExtract_contains`` as the sole hit-matching assertion.
URL-based matching is deferred to V2 (see ``spec.md`` Out of Scope and
``adr-string-matching-vs-llm-judge.md``). The ``webUrl`` of a matched hit is
surfaced in ``matched_items[].matchedHitUrl`` for debugging only — it is
never compared.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from common import STATUS_FAIL, STATUS_PASS

from .utils import (
    FAIL_SCORE,
    PASS_SCORE,
    THRESHOLD,
    extract_texts,
    flatten_hits_with_execution_context,
    get_retrieval_executions,
    has_retrieval_failure,
    normalized_contains,
)

_DEFAULT_MAX_RANK = 10

# Diagnostic_code values.
_DIAG_PASS = "pass"
_DIAG_NOT_RETRIEVED = "not_retrieved"
_DIAG_COUNT_BELOW_MINIMUM = "count_below_minimum"
_DIAG_ERROR = "error"


class RetrievalResultEvaluator:
    """Validate that distinctive extract text appears in retrieved content.

    Configuration parameters (``capability``, ``expected_items``,
    ``min_expected_count``, ``max_rank``) are set via the constructor from
    evaluator config and are not accepted at call time.

    Constructor validation enforces:
        - ``capability`` is required (non-empty string)
        - At least one of ``expected_items`` or ``min_expected_count``
        - Each expected_item has a non-empty ``retrievalExtract_contains``
        - ``webUrl`` on an expected_item is rejected (V1 strict; see ADR)
    """

    def __init__(
        self,
        capability: str,
        expected_items: Optional[List[Dict[str, Any]]] = None,
        min_expected_count: Optional[int] = None,
        max_rank: int = _DEFAULT_MAX_RANK,
    ) -> None:
        if not isinstance(capability, str) or not capability:
            raise ValueError(
                "RetrievalResultEvaluator: 'capability' is required and must be a non-empty string."
            )
        if expected_items is not None and not isinstance(expected_items, list):
            raise ValueError(
                "RetrievalResultEvaluator: 'expected_items' must be a list when provided."
            )
        if min_expected_count is not None:
            if not isinstance(min_expected_count, int) or isinstance(min_expected_count, bool):
                raise ValueError(
                    "RetrievalResultEvaluator: 'min_expected_count' must be an integer."
                )
            if min_expected_count < 1:
                raise ValueError(
                    "RetrievalResultEvaluator: 'min_expected_count' must be >= 1."
                )
        if not isinstance(max_rank, int) or isinstance(max_rank, bool) or max_rank < 1:
            raise ValueError(
                "RetrievalResultEvaluator: 'max_rank' must be a positive integer."
            )

        normalized_items: List[Dict[str, Any]] = []
        if expected_items:
            for idx, item in enumerate(expected_items):
                if not isinstance(item, dict):
                    raise ValueError(
                        f"RetrievalResultEvaluator: expected_items[{idx}] must be an object."
                    )
                if "webUrl" in item:
                    raise ValueError(
                        f"RetrievalResultEvaluator: expected_items[{idx}] uses 'webUrl', which is "
                        "not supported in V1. Use 'retrievalExtract_contains' with a distinctive "
                        "phrase from the expected resource's content instead. See spec.md "
                        "Out of Scope for the V2 forward direction."
                    )
                text = item.get("retrievalExtract_contains")
                if not isinstance(text, str) or not text:
                    raise ValueError(
                        f"RetrievalResultEvaluator: expected_items[{idx}] must have a non-empty "
                        "'retrievalExtract_contains' string."
                    )
                normalized_items.append({"retrievalExtract_contains": text})

        if not normalized_items and min_expected_count is None:
            raise ValueError(
                "RetrievalResultEvaluator: at least one of 'expected_items' or "
                "'min_expected_count' must be configured."
            )

        self.capability = capability
        self.expected_items = normalized_items
        self.min_expected_count = min_expected_count
        self.max_rank = max_rank

    def __call__(
        self,
        *,
        retrieval_telemetry: Optional[Dict[str, Any]] = None,
        response: Optional[str] = None,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        """Evaluate retrieval telemetry against the configured assertions.

        Returns the score dict described in
        ``contracts/retrieval-result-evaluator.md`` Return Value Schema.
        """
        expected_items = self.expected_items
        min_expected_count = self.min_expected_count

        executions = get_retrieval_executions(
            retrieval_telemetry, capability=self.capability
        )
        if has_retrieval_failure(retrieval_telemetry, executions, capability=self.capability):
            return _error_result(
                "Retrieval telemetry unavailable or all matching executions failed"
            )

        candidates = flatten_hits_with_execution_context(
            executions, max_rank=self.max_rank
        )
        candidate_count = len(candidates)

        # Step 1: min_expected_count (count-only short-circuit).
        count_passed = min_expected_count is None or candidate_count >= min_expected_count
        if not count_passed and not expected_items:
            return _build_result(
                score=FAIL_SCORE,
                status=STATUS_FAIL,
                diagnostic_code=_DIAG_COUNT_BELOW_MINIMUM,
                reason=f"Retrieved {candidate_count} results, expected at least {min_expected_count}",
                results_evaluated=candidate_count,
            )

        # Count-only path: count met, no items to check.
        if not expected_items:
            return _build_result(
                score=PASS_SCORE,
                status=STATUS_PASS,
                diagnostic_code=_DIAG_PASS,
                reason=f"{candidate_count} results retrieved (>= {min_expected_count})",
                results_evaluated=candidate_count,
            )

        if not candidates:
            return _not_retrieved_result(
                "No retrieval results found in matching retrieval executions",
                expected_items=expected_items,
            )

        # Step 2: scan candidate extracts for each expected item.
        matched_items: List[Dict[str, Any]] = []
        missing_items: List[Dict[str, Any]] = []
        extract_failures: List[Dict[str, Any]] = []

        for expected in expected_items:
            extract_text = expected["retrievalExtract_contains"]
            matched_hit = _find_first_hit_with_extract(candidates, extract_text)
            if matched_hit is not None:
                matched_items.append({
                    "extractMatch": extract_text,
                    "matchedHitUrl": matched_hit.get("webUrl", ""),
                })
            else:
                # The capability returned hits but none contained the text.
                missing = {"extractMatch": extract_text}
                extract_failures.append(missing)
                missing_items.append(missing)

        items_score = len(matched_items) / len(expected_items)

        # Step 3: combine items + count results.
        if not count_passed:
            return _build_result(
                score=FAIL_SCORE,
                status=STATUS_FAIL,
                diagnostic_code=_DIAG_COUNT_BELOW_MINIMUM,
                reason=(
                    f"Count check failed ({candidate_count} < {min_expected_count}); "
                    f"items: {len(matched_items)}/{len(expected_items)}"
                ),
                results_evaluated=candidate_count,
                matched_items=matched_items,
                missing_items=missing_items,
                extract_failures=extract_failures,
            )

        if items_score == 1.0:
            return _build_result(
                score=PASS_SCORE,
                status=STATUS_PASS,
                diagnostic_code=_DIAG_PASS,
                reason=f"All {len(matched_items)} expected items found within rank {self.max_rank}",
                results_evaluated=candidate_count,
                matched_items=matched_items,
            )

        return _build_result(
            score=items_score,
            status=STATUS_FAIL,
            diagnostic_code=_DIAG_NOT_RETRIEVED,
            reason=(
                f"Found {len(matched_items)}/{len(expected_items)} expected items. "
                f"Missing: {[m['extractMatch'] for m in missing_items]}"
            ),
            results_evaluated=candidate_count,
            matched_items=matched_items,
            missing_items=missing_items,
            extract_failures=extract_failures,
        )


def _build_result(
    *,
    score: float,
    status: str,
    diagnostic_code: str,
    reason: str,
    results_evaluated: int = 0,
    matched_items: Optional[List[Dict[str, Any]]] = None,
    missing_items: Optional[List[Dict[str, Any]]] = None,
    extract_failures: Optional[List[Dict[str, Any]]] = None,
) -> Dict[str, Any]:
    return {
        "retrieval_result": score,
        "result": status,
        "threshold": THRESHOLD,
        "diagnostic_code": diagnostic_code,
        "reason": reason,
        "results_evaluated": results_evaluated,
        "matched_items": matched_items if matched_items is not None else [],
        "missing_items": missing_items if missing_items is not None else [],
        "extract_failures": extract_failures if extract_failures is not None else [],
    }


def _find_first_hit_with_extract(
    candidates: List[Dict[str, Any]],
    extract_text: str,
) -> Optional[Dict[str, Any]]:
    """Return the first candidate hit whose extracts contain ``extract_text``."""
    for hit in candidates:
        for text in extract_texts(hit):
            if normalized_contains(text, extract_text):
                return hit
    return None


def _error_result(reason: str) -> Dict[str, Any]:
    return _build_result(
        score=FAIL_SCORE,
        status=STATUS_FAIL,
        diagnostic_code=_DIAG_ERROR,
        reason=reason,
    )


def _not_retrieved_result(
    reason: str,
    expected_items: List[Dict[str, Any]],
) -> Dict[str, Any]:
    """No candidate hits — every expected item is missing, no extract failures."""
    return _build_result(
        score=FAIL_SCORE,
        status=STATUS_FAIL,
        diagnostic_code=_DIAG_NOT_RETRIEVED,
        reason=reason,
        missing_items=[
            {"extractMatch": item["retrievalExtract_contains"]}
            for item in expected_items
        ],
    )
