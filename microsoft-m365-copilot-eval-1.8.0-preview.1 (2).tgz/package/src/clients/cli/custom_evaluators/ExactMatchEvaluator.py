class ExactMatchEvaluator:
    def __init__(self, case_sensitive=False):
        self.case_sensitive = case_sensitive

    def __call__(self, *, response: str, expected_answer: str, **kwargs):
        if response is None or response.strip() == "":
            raise ValueError("Response is null, empty, or whitespace.")

        if expected_answer is None:
            raise ValueError("Expected answer cannot be None.")

        resp = response.strip()
        exp = expected_answer.strip()

        if not self.case_sensitive:
            resp = resp.lower()
            exp = exp.lower()

        is_match = resp == exp

        return {
            "exact_match": 1.0 if is_match else 0.0,
            "result": "pass" if is_match else "fail",
            "exact_match_reason": "Exact match found" if is_match else "No exact match found"
        }
