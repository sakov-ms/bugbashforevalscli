#from azure.ai.evaluation import evaluate

class ConcisenessNonLLMEvaluator:
    def __init__(self):
        pass
    # A class is made callable by implementing the special method __call__
    def __call__(self, *, response: str, **kwargs):
        length = len(response)
        # compute raw score (example: normalized to roughly 0-5)
        raw_score = max(0, ((100 - (length / 10)) / 20))
        # round to nearest integer
        rounded = int(round(raw_score))
        return {
            "concisenessnonllm_score": rounded,
            "concisenessnonllm_threshold": 3,
            "concisenessnonllm_result": "pass" if rounded >= 3 else "fail",
            "concisenessnonllm_reason": f"Any response greater than 1000 characters is given zero score. The longer the answer, the lesser the score. The length of the response is {length} chars. And hence, the score!"
            }