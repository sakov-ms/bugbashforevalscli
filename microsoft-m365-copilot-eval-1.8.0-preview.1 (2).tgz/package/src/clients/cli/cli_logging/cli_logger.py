"""Shared CLI logger instance and structured-log convenience wrapper.

Every module in the CLI layer that needs to emit diagnostics imports from here
instead of main.py, which avoids circular-import issues.
"""

import logging
import sys
from typing import Any, Dict, List

from cli_logging.console_diagnostics import emit_structured_log as _emit_structured_log
from cli_logging.logging_utils import LOG_LEVEL_MAP, Operation

CLI_LOGGER_NAME = "m365.eval.cli"
CLI_LOGGER = logging.getLogger(CLI_LOGGER_NAME)
DIAGNOSTIC_RECORDS: List[Dict[str, Any]] = []


def configure_cli_logging(effective_log_level: str) -> None:
    if not CLI_LOGGER.handlers:
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(logging.Formatter("%(message)s"))
        CLI_LOGGER.addHandler(handler)
        CLI_LOGGER.propagate = False
    CLI_LOGGER.setLevel(LOG_LEVEL_MAP[effective_log_level])

    # Route MSAL / Azure / msal_extensions stdlib loggers through CLI_LOGGER.
    # Imported here (not at module top) to avoid a circular import:
    # third_party_logging imports CLI_LOGGER and DIAGNOSTIC_RECORDS from here.
    from cli_logging.third_party_logging import configure_third_party_logging
    configure_third_party_logging(effective_log_level)


def emit_structured_log(level: str, message: str, operation: str = Operation.EVALUATE) -> None:
    _emit_structured_log(
        level, message, operation,
        logger=CLI_LOGGER,
        diagnostic_records=DIAGNOSTIC_RECORDS,
    )
