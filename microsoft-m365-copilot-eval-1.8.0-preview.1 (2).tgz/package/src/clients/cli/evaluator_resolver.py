"""Evaluator resolution module for per-prompt evaluator configuration.

Resolves which evaluators to run on each prompt by merging prompt-level config
with file-level defaults and system defaults, following extend/replace modes.
"""

import difflib
import logging
from typing import Any, Dict, Optional

from common import (
    RELEVANCE,
    COHERENCE,
    GROUNDEDNESS,
    SIMILARITY,
    CITATIONS,
    EXACT_MATCH,
    PARTIAL_MATCH,
    RETRIEVAL_QUERY,
    RETRIEVAL_RESULT,
    SYSTEM_DEFAULT_EVALUATORS,
    RegistryEntry,
)

logger = logging.getLogger(__name__)


# Static registry of available evaluators per data-model.md
EVALUATOR_REGISTRY: Dict[str, RegistryEntry] = {
    RELEVANCE: RegistryEntry(type="llm", default_threshold=3),
    COHERENCE: RegistryEntry(type="llm", default_threshold=3),
    GROUNDEDNESS: RegistryEntry(type="llm", default_threshold=3),
    SIMILARITY: RegistryEntry(type="llm", default_threshold=3),
    CITATIONS: RegistryEntry(type="non-llm", default_threshold=1),
    EXACT_MATCH: RegistryEntry(type="non-llm", default_threshold=None),
    PARTIAL_MATCH: RegistryEntry(type="non-llm", default_threshold=0.5),
    RETRIEVAL_QUERY: RegistryEntry(type="non-llm", default_threshold=1.0),
    RETRIEVAL_RESULT: RegistryEntry(type="non-llm", default_threshold=1.0),
}

# Evaluators whose threshold is pinned by contract and cannot be overridden.
_FIXED_THRESHOLD_EVALUATORS = frozenset({RETRIEVAL_QUERY, RETRIEVAL_RESULT})


def validate_evaluator_names(evaluator_map: Dict[str, Any]) -> None:
    """Validate that all evaluator names in the map exist in the registry.

    Raises ValueError with categorized valid names and
    'Did you mean?' suggestions for close matches.
    """
    invalid_names = [name for name in evaluator_map if name not in EVALUATOR_REGISTRY]
    if not invalid_names:
        return

    # Categorize valid evaluators for the error message
    llm_evals = [n for n, r in EVALUATOR_REGISTRY.items() if r.type == "llm"]
    tool_evals = [n for n, r in EVALUATOR_REGISTRY.items() if r.type == "tool"]
    non_llm_evals = [n for n, r in EVALUATOR_REGISTRY.items() if r.type == "non-llm"]

    lines = []
    for name in invalid_names:
        lines.append(f'Unknown evaluator "{name}".')
        close = difflib.get_close_matches(name, EVALUATOR_REGISTRY.keys(), n=1, cutoff=0.5)
        if close:
            lines.append(f'Did you mean "{close[0]}"?')

    lines.append("")
    lines.append("Valid evaluators are:")
    for category, label in [
        (llm_evals, "LLM-based"),
        (tool_evals, "tool evaluation"),
        (non_llm_evals, "non-LLM"),
    ]:
        if category:
            lines.append(f"  - {', '.join(category)} ({label})")

    raise ValueError("\n".join(lines))


def validate_evaluator_options(evaluator_map: Dict[str, Any]) -> None:
    """Reject per-evaluator option keys that aren't supported by the evaluator.
    """
    violations = []
    for eval_name, options in evaluator_map.items():
        if not isinstance(options, dict):
            continue
        if eval_name in _FIXED_THRESHOLD_EVALUATORS and "threshold" in options:
            pinned = EVALUATOR_REGISTRY[eval_name].default_threshold
            violations.append(
                f"'threshold' is not configurable on {eval_name} "
                f"(pinned at {pinned} by contract). Remove the key."
            )
    if violations:
        raise ValueError("\n".join(violations))


def resolve_default_evaluators(file_defaults: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Resolve effective default evaluators, falling back to system defaults.

    Precedence: file-level defaults > system defaults.
    An explicit empty dict means "no default evaluators".
    """
    # File-level defaults (including explicit empty dict)
    if file_defaults is not None:
        return file_defaults

    # System defaults
    return {name: {} for name in SYSTEM_DEFAULT_EVALUATORS}


def resolve_evaluators_for_prompt(
    prompt_evaluators: Optional[Dict[str, Any]],
    evaluators_mode: str,
    prompt: str,
    default_evaluators: Dict[str, Any],
) -> Dict[str, Any]:
    """Resolve which evaluators to run for a single prompt.

    Args:
        prompt_evaluators: Per-prompt evaluator config (None if not specified).
        evaluators_mode: How to combine with defaults ("extend" or "replace").
        prompt: The prompt text (used in warning messages).
        default_evaluators: Resolved default evaluators (from resolve_default_evaluators).

    Returns:
        Resolved EvaluatorMap (dict of evaluator_name -> options).
    """
    # No prompt-level config → use defaults
    if prompt_evaluators is None:
        return dict(default_evaluators)

    if evaluators_mode == "replace":
        if not prompt_evaluators:
            logger.warning(
                "Empty evaluators with 'replace' mode for prompt: '%s'. "
                "No evaluators will run.",
                prompt[:80],
            )
        return dict(prompt_evaluators)

    # mode == "extend": merge defaults with prompt overrides (prompt wins on conflict)
    merged = dict(default_evaluators)
    merged.update(prompt_evaluators)
    return merged


def get_evaluator_threshold(evaluator_name: str, options: Dict[str, Any]) -> Optional[float]:
    """Get the threshold for an evaluator, with option override support."""
    if "threshold" in options:
        return options["threshold"]
    entry = EVALUATOR_REGISTRY.get(evaluator_name)
    return entry.default_threshold if entry else None
