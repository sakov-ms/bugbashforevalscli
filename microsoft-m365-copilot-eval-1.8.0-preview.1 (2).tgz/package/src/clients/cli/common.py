"""Shared types and constants for the CLI."""

import re
from dataclasses import dataclass
from typing import List, Optional

MAX_CONCURRENCY = 5
MAX_ATTEMPTS = 4  # Initial attempt + 3 retries
MAX_TURNS_PER_THREAD = 20
LONG_THREAD_WARNING_THRESHOLD = 10
DEFAULT_PASS_THRESHOLD = 3

# ── Environment variable name constants ──────────────────────────────
ENV_AZURE_AI_OPENAI_ENDPOINT = "AZURE_AI_OPENAI_ENDPOINT"
ENV_AZURE_AI_API_KEY = "AZURE_AI_API_KEY"
ENV_AZURE_AI_API_VERSION = "AZURE_AI_API_VERSION"
ENV_AZURE_AI_MODEL_NAME = "AZURE_AI_MODEL_NAME"
ENV_TENANT_ID = "TENANT_ID"
ENV_WORK_IQ_A2A_ENDPOINT = "WORK_IQ_A2A_ENDPOINT"
ENV_WORK_IQ_A2A_CLIENT_ID = "WORK_IQ_A2A_CLIENT_ID"
ENV_WORK_IQ_A2A_SCOPES = "WORK_IQ_A2A_SCOPES"


def pascal_case_to_title(eval_name: str) -> str:
    """Convert PascalCase evaluator name to space-separated display name.

    e.g., "ToolCallAccuracy" → "Tool Call Accuracy"
    """
    return re.sub(r'(?<=[a-z])(?=[A-Z])', ' ', eval_name)


# Canonical evaluator name constants
RELEVANCE = "Relevance"
COHERENCE = "Coherence"
GROUNDEDNESS = "Groundedness"
SIMILARITY = "Similarity"
TOOL_CALL_ACCURACY = "ToolCallAccuracy"
CITATIONS = "Citations"
EXACT_MATCH = "ExactMatch"
PARTIAL_MATCH = "PartialMatch"
RETRIEVAL_QUERY = "RetrievalQuery"
RETRIEVAL_RESULT = "RetrievalResult"

# Evaluation status constants — four-value enum used at the turn/item level
# AND the thread-level overall_status. See status_derivation.py for the
# canonical derivation and rollup rules.
STATUS_PASS = "pass"
STATUS_FAIL = "fail"
STATUS_PARTIAL = "partial"
STATUS_ERROR = "error"
# Internal-only sentinel — never appears in emitted output.
STATUS_UNKNOWN = "unknown"

# System defaults when no file-level or env-level defaults are configured
SYSTEM_DEFAULT_EVALUATORS = [
    RELEVANCE,
    COHERENCE,
]


# Mapping from evaluator name to the key used in evaluator output dicts
METRIC_IDS = {
    RELEVANCE: "relevance",
    COHERENCE: "coherence",
    GROUNDEDNESS: "groundedness",
    SIMILARITY: "similarity",
    TOOL_CALL_ACCURACY: "tool_call_accuracy",
    CITATIONS: "citations",
    EXACT_MATCH: "exact_match",
    PARTIAL_MATCH: "partial_match",
    RETRIEVAL_QUERY: "retrieval_query",
    RETRIEVAL_RESULT: "retrieval_result",
}


@dataclass
class RegistryEntry:
    type: str  # "llm", "tool", or "non-llm"
    default_threshold: Optional[float]


@dataclass(frozen=True)
class RunConfig:
    """Typed, immutable runtime configuration passed across module boundaries.

    Use ``RunConfig.from_namespace(args)`` to build from argparse output.
    Use ``dataclasses.replace(config, field=value)`` to derive new configs.
    """
    prompts: Optional[List[str]] = None
    expected: Optional[List[str]] = None
    prompts_file: Optional[str] = None
    interactive: bool = False
    m365_agent_id: Optional[str] = None
    output: Optional[str] = None
    log_level: Optional[List[str]] = None
    effective_log_level: str = "info"
    signout: bool = False
    concurrency: int = MAX_CONCURRENCY

    @classmethod
    def from_namespace(cls, args) -> "RunConfig":
        """Build a RunConfig from an argparse.Namespace."""
        return cls(
            prompts=args.prompts,
            expected=args.expected,
            prompts_file=args.prompts_file,
            interactive=args.interactive,
            m365_agent_id=args.m365_agent_id,
            output=args.output,
            log_level=args.log_level,
            signout=args.signout,
            concurrency=args.concurrency,
        )
