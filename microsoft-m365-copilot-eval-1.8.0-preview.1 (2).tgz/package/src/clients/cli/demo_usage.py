#!/usr/bin/env python3
"""
Example usage script for the M365 Copilot Agent Evaluation CLI
This script demonstrates various ways to use the CLI tool.
"""

import subprocess
import sys
import os
from pathlib import Path

def run_command(cmd, description):
    """Run a command and display its description."""
    print(f"\n{'='*60}")
    print(f"Example: {description}")
    print(f"Command: {cmd}")
    print(f"{'='*60}")
    
    try:
        # Note: In a real scenario, you would have your Azure credentials configured
        # This will fail without proper environment variables, but shows the CLI interface
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=30)
        if result.returncode == 0:
            print("✅ Command executed successfully")
            print(result.stdout)
        else:
            print("❌ Command failed (likely due to missing Azure credentials)")
            print("Error:", result.stderr)
    except subprocess.TimeoutExpired:
        print("⏱️ Command timed out (this is expected without Azure credentials)")
    except Exception as e:
        print(f"❌ Error running command: {e}")

def main():
    """Demonstrate CLI usage examples."""
    script_dir = Path(__file__).parent
    os.chdir(script_dir)
    
    print("M365 Copilot Agent Evaluation CLI - Usage Examples")
    print("=" * 60)
    print("Note: These examples will fail without proper Azure credentials.")
    print("This script demonstrates the CLI interface and available options.")
    
    # Example 1: Show help
    run_command(
        "python main.py --help",
        "Display help and all available options"
    )
    
    # Example 2: Custom prompt (dry run)
    run_command(
        'python main.py --prompts "What is Microsoft Graph?" --expected "Microsoft Graph is a gateway to data and intelligence in Microsoft 365."',
        "Run evaluation with custom prompt and expected response"
    )
    
    # Example 3: Prompts from file
    run_command(
        "python main.py --prompts-file samples/example_prompts.json --output results.json",
        "Load prompts from JSON file and save results to JSON"
    )
    
    # Example 4: CSV output
    run_command(
        "python main.py --prompts-file samples/example_prompts.json --output results.csv --format csv",
        "Load prompts from file and save results to CSV"
    )
    
    print(f"\n{'='*60}")
    print("Setup Instructions:")
    print("1. Install Azure CLI and run 'az login' to authenticate")
    print("2. Create a .env file with your Azure AI configuration")
    print("3. Set the following environment variables:")
    print("   - AZURE_AI_FOUNDRY_PROJECT_ENDPOINT")
    print("   - AZURE_AI_AGENT_ID")
    print("   - AZURE_AI_OPENAI_ENDPOINT")
    print("   - AZURE_AI_API_KEY")
    print("   - AZURE_AI_API_VERSION")
    print("   - AZURE_AI_MODEL_NAME")
    print("4. Run: python main.py")
    print(f"{'='*60}")

if __name__ == "__main__":
    main()
