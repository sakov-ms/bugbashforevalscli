"""CLI argument parsing and version-check bypass logic."""

import argparse
import os

from cli_logging.cli_logger import emit_structured_log
from cli_logging.logging_utils import Operation
from common import MAX_CONCURRENCY, RunConfig
from agent_selector import normalize_agent_id


# Flags that should bypass remote min-version enforcement.
# --help is not needed here because argparse exits before runtime checks.
VERSION_CHECK_BYPASS_FLAGS = (
    "signout",
)


def should_bypass_min_version_check(config: RunConfig) -> bool:
    """Return True if the current invocation should skip min-version checks."""
    return any(getattr(config, flag, False) for flag in VERSION_CHECK_BYPASS_FLAGS)


def parse_arguments():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(
        description="M365 Copilot Agent Evaluation CLI",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Run with default prompts
  python main.py

  # Run with custom prompts
  python main.py --prompts "What is Microsoft Graph?" --expected "Microsoft Graph is a gateway..."

  # Run with prompts from file
  python main.py --prompts-file prompts.json

  # Interactive mode
  python main.py --interactive

  # Save results to JSON
  python main.py --output results.json

  # Save results to CSV
  python main.py --output results.csv

  # Save results to HTML and open in browser
  python main.py --output report.html

  # Debug-level diagnostics
  python main.py --log-level debug

  # Sign out and clear cached authentication tokens
  python main.py --signout
        """
    )
    
    # Input options (mutually exclusive)
    input_group = parser.add_mutually_exclusive_group()
    input_group.add_argument(
        '--prompts', 
        nargs='+', 
        help='List of prompts to evaluate'
    )
    input_group.add_argument(
        '--prompts-file', 
        type=str, 
        help='JSON file containing prompts and expected responses'
    )
    input_group.add_argument(
        '--interactive', 
        action='store_true', 
        help='Interactive mode to enter prompts'
    )
    
    # Expected responses (only used with --prompts)
    parser.add_argument(
        '--expected', 
        nargs='+', 
        help='List of expected responses (must match number of prompts)'
    )
    
    # Agent ID (--m365-agent-id is primary, --agent-id kept for backward compatibility)
    parser.add_argument(
        '--m365-agent-id', '--agent-id',
        type=str,
        default=os.environ.get("M365_AGENT_ID") or os.environ.get("AGENT_ID"),
        help='Agent ID (default from M365_AGENT_ID environment variable)'
    )

    # Output options
    parser.add_argument(
        '--output', 
        type=str, 
        help='Output file path. Format is determined by file extension: .json, .csv, .html. If not provided, results are printed to console.'
    )
    
    # Behavior options
    parser.add_argument(
        '--log-level',
        nargs='?',
        const='info',
        action='append',
        help='Set log verbosity: debug, info, warning, error. Bare --log-level resolves to info.'
    )

    parser.add_argument(
        '--signout',
        action='store_true',
        help='Sign out and clear cached authentication tokens'
    )

    parser.add_argument(
        '--concurrency',
        type=int,
        default=MAX_CONCURRENCY,
        help=f'Number of parallel workers for prompt processing (1-{MAX_CONCURRENCY}, default: {MAX_CONCURRENCY})'
    )
    
    args = parser.parse_args()

    args.m365_agent_id = normalize_agent_id(args.m365_agent_id)

    if args.concurrency < 1:
        parser.error('--concurrency must be an integer >= 1.')
    if args.concurrency > MAX_CONCURRENCY:
        emit_structured_log(
            "warning",
            f"--concurrency {args.concurrency} exceeds max {MAX_CONCURRENCY}; clamping to {MAX_CONCURRENCY}.",
            operation=Operation.SETUP,
        )
        args.concurrency = MAX_CONCURRENCY

    return args
