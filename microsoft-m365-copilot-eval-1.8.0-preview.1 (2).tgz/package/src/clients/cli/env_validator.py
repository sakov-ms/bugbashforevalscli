"""Environment validation and URL security checks."""

import os
import sys
import urllib.parse
from typing import List

from cli_logging.cli_logger import emit_structured_log
from cli_logging.logging_utils import Operation
from common import (
    ENV_AZURE_AI_OPENAI_ENDPOINT,
    ENV_AZURE_AI_API_KEY,
    ENV_AZURE_AI_API_VERSION,
    ENV_AZURE_AI_MODEL_NAME,
    ENV_WORK_IQ_A2A_ENDPOINT,
    ENV_WORK_IQ_A2A_CLIENT_ID,
    ENV_WORK_IQ_A2A_SCOPES,
    ENV_TENANT_ID,
)


# Allowed endpoints for URL validation
ALLOWED_ENDPOINTS = [
    'substrate.office.com',
    'graph.microsoft.com',
]


def validate_environment() -> None:
    """Validate required environment variables."""
    required_env_vars = [
        ENV_AZURE_AI_OPENAI_ENDPOINT,
        ENV_AZURE_AI_API_KEY,
        ENV_AZURE_AI_API_VERSION,
        ENV_AZURE_AI_MODEL_NAME,
        ENV_WORK_IQ_A2A_ENDPOINT,
        ENV_WORK_IQ_A2A_CLIENT_ID,
        ENV_WORK_IQ_A2A_SCOPES,
        ENV_TENANT_ID,
    ]

    missing_vars = [
        var for var in required_env_vars if not os.environ.get(var)
    ]
    if missing_vars:
        emit_structured_log(
            "error",
            "Missing required environment variables: "
            f"{', '.join(missing_vars)}. Please ensure your .env file"
            " contains all required configuration.",
            operation=Operation.VALIDATE_ENV,
        )
        sys.exit(1)


def validate_endpoint_url(url: str, allowed_domains: List[str]) -> None:
    """Validate URL against security requirements."""
    try:
        parsed = urllib.parse.urlparse(url)
    except Exception as e:
        raise ValueError(f"Invalid URL format: {url}") from e

    if parsed.scheme in ['javascript', 'data']:
        raise ValueError(f"Dangerous URL scheme detected: {parsed.scheme}")

    if parsed.scheme != 'https':
        raise ValueError(f"Only HTTPS URLs are allowed, got: {parsed.scheme}")

    if parsed.netloc not in allowed_domains:
        raise ValueError(f"Domain not in allowed list: {parsed.netloc}")

    if parsed.fragment:
        raise ValueError("Fragment URLs are not allowed")
